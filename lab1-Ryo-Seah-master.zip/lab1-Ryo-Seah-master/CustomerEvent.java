

class CustomerEvent extends Event {
  /** 
   * The id of a customer associated with this event.  
   * First customer has id 0. Next is 1, 2, etc. 
   */
  public int customerId;
  

  

}   

