# CS2030S AY22/23 Sem 2 Lab 1
## Feedback for Ryo-Seah

The tutor has marked your code. You can find [the comments from your tutor here](https://www.github.com/nus-cs2030s-2223-s2/lab1-Ryo-Seah/commit/9988b8bca7355b537df674381ce683f5542970d7).
### Summary

| Component | Marks |
|-----------|-------|
| Correctness | 3 |
| Design | 11 |
| **TOTAL** | 14 |
